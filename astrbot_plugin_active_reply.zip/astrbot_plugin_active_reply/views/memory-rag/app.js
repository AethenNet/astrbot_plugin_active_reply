/* 主动回复 · 记忆 RAG 管理面板 */
(function () {
  "use strict";

  var bridge = window.AstrBotPluginView;
  var state = {
    page: 1,
    pageSize: 20,
    keyword: "",
    groupScope: "",
    roleId: "",
    total: 0,
    hasMore: false,
  };

  function $(id) { return document.getElementById(id); }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function toast(msg) {
    $("toast").textContent = msg;
    $("toast").classList.add("show");
    clearTimeout(toast._timer);
    toast._timer = setTimeout(function () {
      $("toast").classList.remove("show");
    }, 2200);
  }

  function formatTime(iso) {
    return iso ? String(iso).replace("T", " ").slice(0, 19) : "-";
  }

  /* ---------------- 统计 ---------------- */

  async function loadStats() {
    try {
      var resp = await bridge.apiGet("/memory/stats");
      var stats = resp.data || {};
      $("statTotal").textContent = stats.total_memories != null ? stats.total_memories : "-";
      $("statRoles").textContent = stats.role_count != null ? stats.role_count : "-";
      $("statGroups").textContent = stats.group_id_count != null ? stats.group_id_count : "-";
      $("statScopes").textContent = stats.group_scope_count != null ? stats.group_scope_count : "-";
    } catch (err) {
      $("statTotal").textContent = "-";
    }
  }

  /* ---------------- 列表 ---------------- */

  function buildQuery() {
    return (
      "/memory/list?page=" + state.page +
      "&page_size=" + state.pageSize +
      "&keyword=" + encodeURIComponent(state.keyword) +
      "&group_scope=" + encodeURIComponent(state.groupScope) +
      "&role_id=" + encodeURIComponent(state.roleId)
    );
  }

  async function loadList() {
    var body = $("tableBody");
    body.innerHTML = '<tr><td colspan="6" class="empty-cell">加载中…</td></tr>';
    try {
      var resp = await bridge.apiGet(buildQuery());
      var data = resp.data || {};
      var items = data.items || [];
      state.total = data.total || 0;
      state.hasMore = !!data.has_more;
      renderRows(body, items);
      renderPagination();
    } catch (err) {
      body.innerHTML =
        '<tr><td colspan="6" class="empty-cell">加载失败：' +
        esc(err && err.message ? err.message : err) + "</td></tr>";
    }
  }

  function renderRows(body, items) {
    if (!items.length) {
      body.innerHTML = '<tr><td colspan="6" class="empty-cell">暂无记忆记录</td></tr>';
      return;
    }
    body.innerHTML = "";
    items.forEach(function (item) {
      var tr = document.createElement("tr");
      tr.addEventListener("click", function () { openDetail(item.memory_id); });

      var tdId = document.createElement("td");
      tdId.textContent = item.memory_id;
      tr.appendChild(tdId);

      var tdContent = document.createElement("td");
      tdContent.className = "content-cell";
      tdContent.textContent = item.content || "";
      tdContent.title = item.content || "";
      tr.appendChild(tdContent);

      var tdRoles = document.createElement("td");
      var roles = item.related_role_ids || [];
      var roleWrap = document.createElement("div");
      roleWrap.className = "role-tags";
      roles.slice(0, 3).forEach(function (role) {
        var tag = document.createElement("span");
        tag.className = "role-tag";
        tag.textContent = role;
        roleWrap.appendChild(tag);
      });
      if (roles.length > 3) {
        var more = document.createElement("span");
        more.className = "role-tag";
        more.textContent = "+" + (roles.length - 3);
        roleWrap.appendChild(more);
      }
      tdRoles.appendChild(roleWrap);
      tr.appendChild(tdRoles);

      var tdScope = document.createElement("td");
      tdScope.textContent = item.group_scope || "-";
      tr.appendChild(tdScope);

      var tdTime = document.createElement("td");
      tdTime.className = "time-cell";
      tdTime.textContent = formatTime(item.memory_time_iso);
      tr.appendChild(tdTime);

      var tdOp = document.createElement("td");
      tdOp.className = "op-cell";
      var del = document.createElement("button");
      del.className = "btn danger small";
      del.textContent = "删除";
      del.addEventListener("click", function (e) {
        e.stopPropagation();
        deleteMemory(item.memory_id);
      });
      tdOp.appendChild(del);
      tr.appendChild(tdOp);

      body.appendChild(tr);
    });
  }

  function renderPagination() {
    var totalPages = state.pageSize > 0 ? Math.max(1, Math.ceil(state.total / state.pageSize)) : 1;
    $("pageInfo").textContent = "第 " + state.page + " / " + totalPages + " 页 · 共 " + state.total + " 条";
    $("prevBtn").disabled = state.page <= 1;
    $("nextBtn").disabled = !state.hasMore;
  }

  /* ---------------- 详情 ---------------- */

  function openDrawer() {
    $("drawer").classList.add("open");
    $("drawerMask").style.display = "block";
  }
  function closeDrawer() {
    $("drawer").classList.remove("open");
    $("drawerMask").style.display = "none";
  }

  async function openDetail(memoryId) {
    $("drawerBody").innerHTML = "加载中…";
    openDrawer();
    try {
      var resp = await bridge.apiGet("/memory/" + memoryId);
      var m = resp.data || {};
      var html = "";

      html += '<div class="detail-block"><div class="detail-label">内容</div>' +
        '<div class="detail-content">' + esc(m.content) + "</div></div>";

      html += '<div class="detail-block"><div class="detail-label">信息</div>';
      html += '<div class="detail-row"><span class="k">记忆 ID</span><span>' + esc(m.memory_id) + "</span></div>";
      html += '<div class="detail-row"><span class="k">角色</span><span>' + esc((m.related_role_ids || []).join(", ") || "-") + "</span></div>";
      html += '<div class="detail-row"><span class="k">群范围</span><span>' + esc(m.group_scope || "-") + "</span></div>";
      html += '<div class="detail-row"><span class="k">群 ID</span><span>' + esc(m.group_id || "-") + "</span></div>";
      html += '<div class="detail-row"><span class="k">平台</span><span>' + esc(m.platform_id || "-") + "</span></div>";
      html += '<div class="detail-row"><span class="k">记忆时间</span><span>' + esc(formatTime(m.memory_time_iso)) + "</span></div>";
      html += '<div class="detail-row"><span class="k">创建时间</span><span>' + esc(formatTime(m.created_at_iso)) + "</span></div>";
      html += '<div class="detail-row"><span class="k">更新时间</span><span>' + esc(formatTime(m.updated_at_iso)) + "</span></div>";
      html += '<div class="detail-row"><span class="k">向量维度</span><span>' + esc(m.embedding_dim) + "</span></div>";
      html += "</div>";

      if (m.extra_metadata && Object.keys(m.extra_metadata).length) {
        html += '<div class="detail-block"><div class="detail-label">额外元数据</div>' +
          '<div class="detail-content">' + esc(JSON.stringify(m.extra_metadata, null, 2)) + "</div></div>";
      }

      $("drawerBody").innerHTML = html;
    } catch (err) {
      $("drawerBody").innerHTML =
        "加载详情失败：" + esc(err && err.message ? err.message : err);
    }
  }

  /* ---------------- 删除 / 清理 ---------------- */

  async function deleteMemory(memoryId) {
    if (!window.confirm("确认删除记忆 #" + memoryId + "？此操作不可恢复。")) return;
    try {
      await bridge.apiPost("/memory/" + memoryId + "/delete", {});
      toast("已删除记忆 #" + memoryId);
      loadList();
      loadStats();
    } catch (err) {
      toast("删除失败：" + (err && err.message ? err.message : err));
    }
  }

  async function cleanupLegacy() {
    if (!window.confirm("确认执行旧数据清理？（迁移/规范化旧记录的时间与元数据）")) return;
    try {
      var resp = await bridge.apiPost("/memory/cleanup", {});
      var result = resp.data || {};
      toast(
        "清理完成：更新 " + (result.updated || 0) +
        " · 时间归一化 " + (result.normalized || 0) +
        " · 元数据刷新 " + (result.metadata_refreshed || 0)
      );
      loadList();
      loadStats();
    } catch (err) {
      toast("清理失败：" + (err && err.message ? err.message : err));
    }
  }

  /* ---------------- 初始化 ---------------- */

  function init() {
    $("refreshBtn").addEventListener("click", function () {
      loadStats();
      loadList();
    });
    $("searchBtn").addEventListener("click", function () {
      state.keyword = $("filterKeyword").value.trim();
      state.groupScope = $("filterScope").value.trim();
      state.roleId = $("filterRole").value.trim();
      state.page = 1;
      loadList();
      loadStats();
    });
    $("filterKeyword").addEventListener("keydown", function (e) {
      if (e.key === "Enter") $("searchBtn").click();
    });
    $("clearBtn").addEventListener("click", function () {
      $("filterKeyword").value = "";
      $("filterScope").value = "";
      $("filterRole").value = "";
      state.keyword = "";
      state.groupScope = "";
      state.roleId = "";
      state.page = 1;
      loadList();
      loadStats();
    });
    $("cleanupBtn").addEventListener("click", cleanupLegacy);
    $("prevBtn").addEventListener("click", function () {
      if (state.page <= 1) return;
      state.page -= 1;
      loadList();
    });
    $("nextBtn").addEventListener("click", function () {
      if (!state.hasMore) return;
      state.page += 1;
      loadList();
    });
    $("drawerClose").addEventListener("click", closeDrawer);
    $("drawerMask").addEventListener("click", closeDrawer);

    bridge.ready().then(function () {
      loadStats();
      loadList();
    }).catch(function (err) {
      $("tableBody").innerHTML =
        '<tr><td colspan="6" class="empty-cell">初始化失败：' + esc(err && err.message ? err.message : err) + "</td></tr>";
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
