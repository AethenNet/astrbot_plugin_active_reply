/* 主动回复 · 群配置 View */
(function () {
  "use strict";

  var bridge = window.AstrBotPluginView;
  var state = {
    schema: null,
    llmProviders: [],
    embeddingProviders: [],
    groups: [],
    currentOrigin: null,
    formValues: {},
  };

  var els = {};

  function $(id) { return document.getElementById(id); }

  function toast(msg) {
    els.toast.textContent = msg;
    els.toast.classList.add("show");
    clearTimeout(toast._timer);
    toast._timer = setTimeout(function () {
      els.toast.classList.remove("show");
    }, 2200);
  }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  /* ---------------- 群列表 ---------------- */

  function renderGroupList() {
    els.groupList.innerHTML = "";
    if (!state.groups.length) {
      els.groupList.innerHTML = '<div class="empty">暂无群。插件运行期间收到群消息后会出现在这里。</div>';
      return;
    }
    state.groups.forEach(function (g) {
      var item = document.createElement("button");
      item.className = "group-item" + (g.origin === state.currentOrigin ? " active" : "");
      item.type = "button";

      var name = document.createElement("span");
      name.className = "gname";
      name.textContent = g.name;
      item.appendChild(name);

      var id = document.createElement("span");
      id.className = "gid";
      id.textContent = g.origin;
      item.appendChild(id);

      var dot = document.createElement("span");
      dot.className = "gdot" + (g.has_override ? "" : " plain");
      dot.title = g.has_override ? "已设置独立配置" : "使用全局配置";
      item.appendChild(dot);

      item.addEventListener("click", function () {
        selectGroup(g.origin);
        closeSidebar();
      });
      els.groupList.appendChild(item);
    });
  }

  function selectGroup(origin) {
    state.currentOrigin = origin;
    renderGroupList();
    renderPaneHead(origin, false);
    els.configPane.innerHTML = '<div class="empty large">加载配置中…</div>';
    loadGroupConfig(origin);
  }

  function renderPaneHead(origin, hasOverride) {
    var group = state.groups.find(function (g) { return g.origin === origin; }) || {};
    var head = document.createElement("div");
    head.className = "pane-head";
    head.innerHTML =
      '<h2>' + esc(group.name || "群配置") + '</h2>' +
      '<span class="origin-chip">' + esc(origin) + '</span>';

    var actions = document.createElement("div");
    actions.className = "pane-actions";

    var resetBtn = document.createElement("button");
    resetBtn.className = "btn warn";
    resetBtn.textContent = "恢复全局配置";
    resetBtn.disabled = !hasOverride;
    resetBtn.addEventListener("click", function () { resetGroupConfig(origin); });
    actions.appendChild(resetBtn);

    var saveBtn = document.createElement("button");
    saveBtn.className = "btn primary";
    saveBtn.textContent = "保存此群配置";
    saveBtn.addEventListener("click", function () { saveGroupConfig(origin); });
    actions.appendChild(saveBtn);

    head.appendChild(actions);
    els.topbarStatus.textContent = hasOverride ? "此群使用独立配置" : "此群使用全局配置";
    els.paneHead.replaceWith(head);
    els.paneHead = head;
  }

  async function loadGroupConfig(origin) {
    try {
      var resp = await bridge.apiGet("/groups/" + encodeURIComponent(origin) + "/config");
      state.formValues = resp.effective || {};
      renderPaneHead(origin, !!resp.has_override);
      renderForm(els.configPane, state.schema, state.formValues, "");
    } catch (err) {
      els.configPane.innerHTML = '<div class="empty large">加载配置失败：' + esc(err && err.message ? err.message : err) + "</div>";
    }
  }

  async function saveGroupConfig(origin) {
    var payload = collectFormValues();
    if (!payload) return;
    try {
      await bridge.apiPost(
        "/groups/" + encodeURIComponent(origin) + "/config",
        { config: payload }
      );
      toast("已保存此群独立配置");
      await refreshGroups(false);
      renderPaneHead(origin, true);
    } catch (err) {
      toast("保存失败：" + (err && err.message ? err.message : err));
    }
  }

  async function resetGroupConfig(origin) {
    try {
      await bridge.apiPost(
        "/groups/" + encodeURIComponent(origin) + "/config/reset",
        {}
      );
      toast("已恢复全局配置");
      await refreshGroups(false);
      await loadGroupConfig(origin);
    } catch (err) {
      toast("重置失败：" + (err && err.message ? err.message : err));
    }
  }

  async function refreshGroups(preserveSelection) {
    try {
      var resp = await bridge.apiGet("/groups");
      state.groups = resp.groups || [];
      if (!preserveSelection && state.currentOrigin) {
        var still = state.groups.some(function (g) { return g.origin === state.currentOrigin; });
        if (!still) state.currentOrigin = null;
      }
      renderGroupList();
      if (!state.currentOrigin && state.groups.length) {
        selectGroup(state.groups[0].origin);
      }
    } catch (err) {
      toast("刷新群列表失败：" + (err && err.message ? err.message : err));
    }
  }

  /* ---------------- Schema 表单渲染 ---------------- */

  function renderForm(container, schema, values, path) {
    container.innerHTML = "";
    if (!schema || typeof schema !== "object") {
      container.innerHTML = '<div class="empty large">配置 Schema 为空。</div>';
      return;
    }
    Object.keys(schema).forEach(function (key) {
      var item = schema[key];
      if (!item || typeof item !== "object") return;
      if (item.type === "object") {
        container.appendChild(renderSection(item, values, key));
      } else {
        container.appendChild(renderFieldBlock(item, values, key));
      }
    });
  }

  function renderSection(item, values, key) {
    var section = document.createElement("div");
    section.className = "section";

    var head = document.createElement("div");
    head.className = "section-head";
    head.innerHTML =
      "<h3>" + esc(item.description || key) + "</h3>" +
      (item.hint ? '<span class="hint">' + esc(item.hint) + "</span>" : "");
    section.appendChild(head);

    if (item.hint) {
      var hint = document.createElement("div");
      hint.className = "section-hint";
      hint.textContent = item.hint;
      section.appendChild(hint);
    }

    var body = document.createElement("div");
    body.className = "section-body";
    var childValues = values[key];
    if (childValues && typeof childValues === "object") {
      Object.keys(item.items || {}).forEach(function (childKey) {
        var childItem = item.items[childKey];
        if (!childItem || typeof childItem !== "object") return;
        if (childItem.type === "object") {
          body.appendChild(renderNested(childItem, childValues, childKey));
        } else {
          body.appendChild(renderFieldBlock(childItem, childValues, childKey));
        }
      });
    }
    section.appendChild(body);
    return section;
  }

  function renderNested(item, values, key) {
    var wrap = document.createElement("div");
    wrap.className = "nested";

    var toggle = document.createElement("div");
    toggle.className = "nested-toggle";
    toggle.innerHTML =
      '<span class="arrow open">▶</span>' +
      "<span>" + esc(item.description || key) + "</span>" +
      (item.hint ? '<span class="hint"> ' + esc(item.hint) + "</span>" : "");
    toggle.addEventListener("click", function () {
      var body = wrap.querySelector(".nested-body");
      var arrow = toggle.querySelector(".arrow");
      var hidden = body.style.display === "none";
      body.style.display = hidden ? "" : "none";
      arrow.classList.toggle("open", hidden);
    });
    wrap.appendChild(toggle);

    var body = document.createElement("div");
    body.className = "nested-body";
    var childValues = values[key];
    if (childValues && typeof childValues === "object") {
      Object.keys(item.items || {}).forEach(function (childKey) {
        var childItem = item.items[childKey];
        if (!childItem || typeof childItem !== "object") return;
        body.appendChild(renderFieldBlock(childItem, childValues, childKey));
      });
    }
    wrap.appendChild(body);
    return wrap;
  }

  function renderFieldBlock(item, values, key) {
    var field = document.createElement("div");
    field.className = "field";

    var label = document.createElement("div");
    label.className = "field-label";
    var labelText = document.createElement("span");
    labelText.textContent = item.description || key;
    label.appendChild(labelText);
    if (item.hint) {
      var hint = document.createElement("span");
      hint.className = "fd-hint";
      hint.textContent = item.hint;
      label.appendChild(hint);
    }
    field.appendChild(label);

    var control = document.createElement("div");
    control.className = "field-control";
    var value = values[key];
    renderControl(control, item, value, key, values);
    field.appendChild(control);
    return field;
  }

  function renderControl(container, item, value, key, parentValues) {
    var type = item.type;
    if (type === "bool") {
      renderSwitch(container, item, value, key);
    } else if (type === "int" || type === "float") {
      if (item.slider) {
        renderSlider(container, item, value, key);
      } else {
        renderNumberInput(container, item, value, key);
      }
    } else if (type === "string") {
      if (item._special && String(item._special).indexOf("select_provider") === 0) {
        renderProviderSelect(container, item, value, key);
      } else if (item.options) {
        renderSelect(container, item, value, key);
      } else {
        renderTextInput(container, item, value, key);
      }
    } else if (type === "text") {
      renderTextarea(container, item, value, key);
    } else if (type === "list") {
      renderListEditor(container, item, value, key);
    } else {
      renderTextInput(container, item, value, key);
    }
  }

  function renderSwitch(container, item, value, key) {
    var sw = document.createElement("label");
    sw.className = "switch";
    sw.innerHTML =
      '<input type="checkbox" data-key="' + esc(key) + '" data-kind="bool"' + (value ? " checked" : "") + ">" +
      '<span class="track"></span>';
    sw.querySelector("input").addEventListener("change", function () {
      this.checked = this.checked;
    });
    container.appendChild(sw);
  }

  function renderSlider(container, item, value, key) {
    var row = document.createElement("div");
    row.className = "slider-row";

    var slider = document.createElement("input");
    slider.type = "range";
    slider.dataset.key = key;
    slider.dataset.kind = "slider";
    var min = item.slider.min, max = item.slider.max, step = item.slider.step;
    slider.min = String(min);
    slider.max = String(max);
    slider.step = String(step);
    var numValue = value == null ? item.default : Number(value);
    if (isNaN(numValue)) numValue = Number(item.default) || 0;
    slider.value = String(numValue);

    var display = document.createElement("span");
    display.className = "slider-value";
    display.textContent = String(numValue);

    slider.addEventListener("input", function () {
      display.textContent = this.value;
    });
    row.appendChild(slider);
    row.appendChild(display);
    container.appendChild(row);
  }

  function renderNumberInput(container, item, value, key) {
    var input = document.createElement("input");
    input.type = "number";
    input.dataset.key = key;
    input.dataset.kind = "number";
    if (item.slider) {
      input.step = String(item.slider.step);
      input.min = String(item.slider.min);
      input.max = String(item.slider.max);
    }
    input.value = value == null ? "" : String(value);
    container.appendChild(input);
  }

  function renderTextInput(container, item, value, key) {
    var input = document.createElement("input");
    input.type = "text";
    input.dataset.key = key;
    input.dataset.kind = "text";
    input.placeholder = item.default != null ? String(item.default) : "";
    input.value = value == null ? "" : String(value);
    container.appendChild(input);
  }

  function renderTextarea(container, item, value, key) {
    var ta = document.createElement("textarea");
    ta.dataset.key = key;
    ta.dataset.kind = "text";
    ta.rows = 4;
    ta.placeholder = item.default != null ? String(item.default) : "";
    ta.value = value == null ? "" : String(value);
    container.appendChild(ta);
  }

  function renderSelect(container, item, value, key) {
    var select = document.createElement("select");
    select.dataset.key = key;
    select.dataset.kind = "select";
    (item.options || []).forEach(function (opt, idx) {
      var option = document.createElement("option");
      option.value = String(opt);
      var label = item.labels && item.labels[idx] ? item.labels[idx] : opt;
      option.textContent = String(label);
      select.appendChild(option);
    });
    select.value = value == null ? String(item.default || "") : String(value);
    container.appendChild(select);
  }

  function renderProviderSelect(container, item, value, key) {
    var isEmbedding = String(item._special).indexOf("embedding") !== -1;
    var list = isEmbedding ? state.embeddingProviders : state.llmProviders;

    var select = document.createElement("select");
    select.dataset.key = key;
    select.dataset.kind = "select";

    var emptyOpt = document.createElement("option");
    emptyOpt.value = "";
    emptyOpt.textContent = isEmbedding
      ? "（留空：自动使用第一个可用 embedding provider）"
      : "（留空：使用当前会话默认提供商）";
    select.appendChild(emptyOpt);

    (list || []).forEach(function (p) {
      var option = document.createElement("option");
      option.value = String(p.id);
      option.textContent = String(p.label || p.id);
      select.appendChild(option);
    });
    select.value = value == null ? "" : String(value);
    container.appendChild(select);
  }

  function renderListEditor(container, item, value, key) {
    var editor = document.createElement("div");
    editor.className = "list-editor";

    var tags = document.createElement("div");
    tags.className = "list-tags";
    editor.appendChild(tags);

    var row = document.createElement("div");
    row.className = "list-input-row";
    var input = document.createElement("input");
    input.type = "text";
    input.placeholder = "输入" + (item.description || "条目") + "后回车/添加";
    var addBtn = document.createElement("button");
    addBtn.className = "btn";
    addBtn.textContent = "添加";
    row.appendChild(input);
    row.appendChild(addBtn);
    editor.appendChild(row);

    var current = Array.isArray(value)
      ? value.slice()
      : Array.isArray(item.default)
        ? item.default.slice()
        : [];
    editor.dataset.key = key;
    editor.dataset.kind = "list";
    editor.dataset.value = JSON.stringify(current);

    function refreshTags() {
      tags.innerHTML = "";
      current.forEach(function (tag, idx) {
        var chip = document.createElement("span");
        chip.className = "list-tag";
        chip.textContent = String(tag);
        var del = document.createElement("button");
        del.type = "button";
        del.textContent = "×";
        del.addEventListener("click", function () {
          current.splice(idx, 1);
          editor.dataset.value = JSON.stringify(current);
          refreshTags();
        });
        chip.appendChild(del);
        tags.appendChild(chip);
      });
    }

    function addValue() {
      var text = input.value.trim();
      if (!text) return;
      if (current.indexOf(text) === -1) current.push(text);
      input.value = "";
      editor.dataset.value = JSON.stringify(current);
      refreshTags();
    }
    addBtn.addEventListener("click", addValue);
    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === ",") {
        e.preventDefault();
        addValue();
      }
    });
    refreshTags();
    container.appendChild(editor);
  }

  /* ---------------- 收集表单值 ---------------- */

  function collectFormValues() {
    var result = {};
    var root = els.configPane;

    function readField(control, parent) {
      var kind = control.dataset ? control.dataset.kind : "";
      if (!kind) return;
      var key = control.dataset.key;
      switch (kind) {
        case "bool":
          parent[key] = control.checked;
          break;
        case "slider":
          parent[key] = Number(control.value);
          break;
        case "number":
          parent[key] = control.value === "" ? null : Number(control.value);
          break;
        case "select":
        case "text":
          parent[key] = control.value;
          break;
        case "list": {
          var raw = control.dataset.value || "[]";
          try {
            parent[key] = JSON.parse(raw);
          } catch (e) {
            parent[key] = [];
          }
          break;
        }
      }
    }

    function walk(container, parent) {
      if (!container || !container.querySelectorAll) return;
      var fields = container.querySelectorAll("[data-kind]");
      for (var i = 0; i < fields.length; i++) {
        readField(fields[i], parent);
      }
    }

    walk(root, result);
    return result;
  }

  /* ---------------- 汉堡菜单 ---------------- */

  function openSidebar() {
    els.sidebar.classList.add("open");
    els.mask.classList.add("show");
  }
  function closeSidebar() {
    els.sidebar.classList.remove("open");
    els.mask.classList.remove("show");
  }

  /* ---------------- 初始化 ---------------- */

  async function init() {
    els.toast = $("toast");
    els.groupList = $("groupList");
    els.configPane = $("configPane");
    els.paneHead = els.configPane.querySelector(".pane-head") || document.createElement("div");
    els.sidebar = $("sidebar");
    els.mask = $("mask");
    els.topbarStatus = $("topbarStatus");

    $("hamburger").addEventListener("click", function () {
      if (els.sidebar.classList.contains("open")) closeSidebar();
      else openSidebar();
    });
    els.mask.addEventListener("click", closeSidebar);
    $("refreshGroups").addEventListener("click", function () {
      refreshGroups(true);
    });

    try {
      await bridge.ready();
      var ctx = bridge.getContext() || {};
      if (ctx.locale === "en-US") {
        document.title = "ActiveReply · Group Config";
        $("topbarTitle").textContent = "Group Config";
      }
      var schemaResp = await bridge.apiGet("/schema");
      state.schema = schemaResp || {};
      var providersResp = await bridge.apiGet("/providers");
      state.llmProviders = providersResp.providers || [];
      state.embeddingProviders = providersResp.embedding_providers || [];
      await refreshGroups(false);
    } catch (err) {
      els.configPane.innerHTML =
        '<div class="empty large">初始化失败：' + esc(err && err.message ? err.message : err) + "</div>";
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
