from __future__ import annotations

import enum
import shutil
import sys
import tempfile
import types
from dataclasses import dataclass, field
from pathlib import Path

import pytest

PLUGIN_ROOT = Path(__file__).resolve().parent.parent
PARENT_ROOT = PLUGIN_ROOT.parent
for path in (PLUGIN_ROOT, PARENT_ROOT):
    path_str = str(path)
    if path_str not in sys.path:
        sys.path.insert(0, path_str)

_TEST_DATA_DIR = tempfile.mkdtemp(prefix="active_reply_test_data_")


@pytest.fixture(autouse=True)
def _clean_test_data_dir():
    """每个测试前清空共享临时数据目录，避免插件数据（群配置覆盖、记忆库）跨测试污染。"""
    shutil.rmtree(_TEST_DATA_DIR, ignore_errors=True)
    Path(_TEST_DATA_DIR).mkdir(parents=True, exist_ok=True)
    yield


def _stub_module(name: str, **attrs) -> types.ModuleType:
    module = types.ModuleType(name)
    for key, value in attrs.items():
        setattr(module, key, value)
    sys.modules[name] = module
    return module


# ---------------- logger ----------------

class _Logger:
    def info(self, *args, **kwargs): pass
    def warning(self, *args, **kwargs): pass
    def error(self, *args, **kwargs): pass
    def debug(self, *args, **kwargs): pass
    def exception(self, *args, **kwargs): pass


logger = _Logger()

# ---------------- 基础组件 ----------------

@dataclass
class Plain:
    text: str = ""
    type: str = "plain"


@dataclass
class At:
    qq: str = ""
    name: str = ""
    type: str = "at"


@dataclass
class Image:
    url: str = ""
    file: str = ""
    name: str | None = None
    type: str = "image"


@dataclass
class Reply:
    id: str = ""
    sender_nickname: str = ""
    message_str: str = ""
    type: str = "reply"


class MessageType(enum.Enum):
    GROUP_MESSAGE = 1
    PRIVATE_MESSAGE = 2
    OTHER = 3


@dataclass
class LLMResponse:
    completion_text: str = ""


class Provider:
    provider_id = "test_provider"
    model = "test-model"
    provider_config: dict = field(default_factory=dict)

    def meta(self):
        return types.SimpleNamespace(id=self.provider_id)

    def get_model(self) -> str:
        return self.model

    def get_current_key(self) -> str:
        return "test-key"

    def get_keys(self):
        return ["test-key"]

    async def text_chat(self, prompt="", session_id="", image_urls=None, persist=True, **kwargs):
        return LLMResponse(completion_text="ok")


class EmbeddingProvider(Provider):
    async def get_embedding(self, text: str) -> list[float]:
        return [0.1, 0.2, 0.3]


@dataclass
class ProviderRequest:
    prompt: str = ""
    system_prompt: str = ""
    contexts: list = field(default_factory=list)
    extra_user_content_parts: list = field(default_factory=list)
    messages: list = field(default_factory=list)


@dataclass
class TextPart:
    text: str = ""
    role: str = "user"


@dataclass
class MessageEventResult:
    chain: list = field(default_factory=list)


class _Request:
    def __init__(self):
        self.query = {}
        self._body = None

    async def json(self, default=None):
        return self._body if self._body is not None else (default or {})


request = _Request()


def json_response(data):
    # 与 astrbot.api.web.json_response 语义一致：将对象序列化为响应体
    return data


def error_response(message, status_code=400):
    return {"error": message, "status_code": status_code}


class PlatformAdapterType:
    ALL = "ALL"
    GROUP = "GROUP"
    PRIVATE = "PRIVATE"


class PermissionType(enum.Enum):
    ADMIN = 1
    MEMBER = 2


def _noop_decorator(*args, **kwargs):
    def wrapper(func):
        return func
    return wrapper


def permission_type(*args, **kwargs):
    return _noop_decorator(*args, **kwargs)


# ---------------- AstrMessageEvent ----------------

class _Sender:
    def __init__(self, nickname="test-user", user_id="123"):
        self.nickname = nickname
        self.user_id = user_id


class AstrMessageEvent:
    def __init__(
        self,
        message_str="",
        message_obj=None,
        unified_msg_origin="qq:10001",
        session_id="s1",
        is_admin_flag=False,
        message_type=MessageType.GROUP_MESSAGE,
    ):
        self.message_str = message_str
        self.message_obj = message_obj or types.SimpleNamespace(
            message=[Plain(text=message_str)],
            sender=_Sender(),
            message_id="999",
        )
        self.unified_msg_origin = unified_msg_origin
        self.session_id = session_id
        self.is_at_or_wake_command = False
        self._is_admin = is_admin_flag
        self._message_type = message_type
        self._extras = {}
        self._result = None

    def get_messages(self):
        return list(self.message_obj.message)

    def get_sender_id(self) -> str:
        sender = getattr(self.message_obj, "sender", None)
        return str(getattr(sender, "user_id", "123"))

    def get_group_id(self) -> str:
        return self.unified_msg_origin.split(":", 1)[1] if ":" in self.unified_msg_origin else self.unified_msg_origin

    def get_platform_id(self) -> str:
        return self.unified_msg_origin.split(":", 1)[0] if ":" in self.unified_msg_origin else "qq"

    def get_platform_name(self) -> str:
        return self.get_platform_id()

    def get_message_type(self):
        return self._message_type

    def is_admin(self) -> bool:
        return self._is_admin

    def get_extra(self, key, default=None):
        return self._extras.get(key, default)

    def set_extra(self, key, value):
        self._extras[key] = value

    def get_result(self):
        return self._result

    def set_result(self, result):
        self._result = result

    def plain_result(self, text):
        self._result = MessageEventResult(chain=[Plain(text=text)])
        return self._result

    async def request_llm(self, prompt="", session_id="", conversation=None, **kwargs):
        yield MessageEventResult(chain=[Plain(text="ok")])


# ---------------- star 框架 ----------------

class Star:
    def __init__(self, context=None, config=None):
        self.context = context
        self.config = config or {}

    async def terminate(self):
        pass


class Context:
    def get_config(self, umo=None):
        return {}

    def get_using_provider(self, umo=None):
        return None

    def get_provider_by_id(self, provider_id):
        return None

    def get_all_providers(self):
        return []

    def get_all_embedding_providers(self):
        return []

    def register_web_api(self, route, handler, methods, desc):
        pass


# ---------------- filter ----------------

class _Filter:
    def __init__(self):
        self.FilterType = types.SimpleNamespace(EventType=type("E", (), {}))
        self.PlatformAdapterType = PlatformAdapterType

    def platform_adapter_type(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)

    def event_message_type(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)

    def event_type(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)

    def on_llm_request(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)

    def on_llm_response(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)

    def on_decorating_result(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)

    def after_message_sent(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)

    def on_astrbot_loaded(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)

    def command(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)

    def command_group(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)


filter_ = _Filter()


# ---------------- llm_tool / sp ----------------

class _LLMTool:
    def __call__(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)

    def register(self, *args, **kwargs):
        return _noop_decorator(*args, **kwargs)


class _SP:
    async def get_async(self, scope="", scope_id="", key="", default=None):
        return default


# ---------------- astrbot.core utils ----------------

def get_astrbot_data_path() -> str:
    return _TEST_DATA_DIR


async def download_image_by_url(url: str) -> str:
    return ""


# ---------------- 组装 astrbot 包 ----------------

astrbot = _stub_module("astrbot")
api = _stub_module("astrbot.api")
_stub_module(
    "astrbot.api.message_components",
    Plain=Plain,
    At=At,
    Image=Image,
    Reply=Reply,
)
_stub_module("astrbot.api.platform", MessageType=MessageType)
_stub_module(
    "astrbot.api.provider",
    LLMResponse=LLMResponse,
    Provider=Provider,
    ProviderRequest=ProviderRequest,
    EmbeddingProvider=EmbeddingProvider,
)
_stub_module(
    "astrbot.api.event",
    AstrMessageEvent=AstrMessageEvent,
    MessageEventResult=MessageEventResult,
    filter=filter_,
)
_stub_module(
    "astrbot.api.event.filter",
    PermissionType=PermissionType,
    permission_type=permission_type,
    PlatformAdapterType=PlatformAdapterType,
)
_stub_module(
    "astrbot.api.web",
    request=request,
    json_response=json_response,
    error_response=error_response,
)
api.logger = logger
api.star = _stub_module("astrbot.api.star", Star=Star, Context=Context)
api.llm_tool = _LLMTool()
api.sp = _SP()
astrbot.api = api

core = _stub_module("astrbot.core")
core.agent = _stub_module("astrbot.core.agent")
_stub_module("astrbot.core.agent.message", TextPart=TextPart)
core.provider = _stub_module("astrbot.core.provider")
_stub_module("astrbot.core.provider.provider", EmbeddingProvider=EmbeddingProvider)
core.utils = _stub_module("astrbot.core.utils")
_stub_module("astrbot.core.utils.astrbot_path", get_astrbot_data_path=get_astrbot_data_path)
_stub_module("astrbot.core.utils.io", download_image_by_url=download_image_by_url)
astrbot.core = core

# ---------------- mcp ----------------

if "mcp" not in sys.modules:
    mcp = _stub_module("mcp")
    mcp_types = _stub_module("mcp.types")

    class TextContent:
        def __init__(self, type="text", text=""):
            self.type = type
            self.text = text

    class ImageContent:
        def __init__(self, type="image", data="", mimeType=""):
            self.type = type
            self.data = data
            self.mimeType = mimeType

    class CallToolResult:
        def __init__(self, content=None):
            self.content = content or []

    mcp_types.TextContent = TextContent
    mcp_types.ImageContent = ImageContent
    mcp_types.CallToolResult = CallToolResult
    mcp.types = mcp_types
