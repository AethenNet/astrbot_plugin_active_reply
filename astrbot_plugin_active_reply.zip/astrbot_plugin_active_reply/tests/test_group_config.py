from __future__ import annotations

import json
import tempfile

from astrbot_plugin_active_reply.group_config import GroupConfigStore


def test_set_get_delete(tmp_path):
    store = GroupConfigStore(tmp_path)
    assert store.get("qq:10001") is None

    store.set("qq:10001", {"active_reply": {"enable": True}})
    assert store.get("qq:10001") == {"active_reply": {"enable": True}}
    assert store.has_override("qq:10001") is True
    assert store.list_origins() == ["qq:10001"]

    assert store.delete("qq:10001") is True
    assert store.get("qq:10001") is None
    assert store.delete("qq:10001") is False


def test_persistence(tmp_path):
    store = GroupConfigStore(tmp_path)
    store.set("qq:10001", {"active_reply": {"enable": True, "possibility": 0.5}})
    store.set("qq:10002", {"web_search": {"enable": True}})

    reloaded = GroupConfigStore(tmp_path)
    assert reloaded.get("qq:10001") == {
        "active_reply": {"enable": True, "possibility": 0.5}
    }
    assert reloaded.get("qq:10002") == {"web_search": {"enable": True}}


def test_corrupted_file_is_tolerated(tmp_path):
    store = GroupConfigStore(tmp_path)
    store.set("qq:10001", {"active_reply": {"enable": True}})
    store._store_path.write_text("{not valid json", encoding="utf-8")

    reloaded = GroupConfigStore(tmp_path)
    assert reloaded.get("qq:10001") is None
    assert reloaded.list_origins() == []


def test_empty_or_invalid_origin():
    store = GroupConfigStore(tempfile.mkdtemp())
    store.set("", {"a": 1})
    assert store.list_origins() == []
    assert store.delete("") is False
    assert store.get("") is None

    store.set("qq:1", None)
    assert store.has_override("qq:1") is False


def test_deep_copy_on_set(tmp_path):
    store = GroupConfigStore(tmp_path)
    payload = {"active_reply": {"enable": True}}
    store.set("qq:10001", payload)
    payload["active_reply"]["enable"] = False  # 修改原对象
    stored = store.get("qq:10001")
    assert stored["active_reply"]["enable"] is True

    stored["active_reply"]["enable"] = False  # 修改返回对象
    assert store.get("qq:10001")["active_reply"]["enable"] is True
