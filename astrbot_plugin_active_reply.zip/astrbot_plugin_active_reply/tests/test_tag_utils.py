from __future__ import annotations

from astrbot.api.message_components import At, Plain, Reply

from astrbot_plugin_active_reply.tag_utils import (
    bounded_chat_history_text,
    chain_has_refuse_tag,
    clean_response_text_for_history,
    has_refuse_tag,
    normalize_quote_id,
    transform_result_chain,
)


def test_transform_mention():
    chain = [Plain(text="你好 <mention id=\"123\"/> 世界")]
    result = transform_result_chain(chain, parse_mention=True)
    assert result is not None
    assert isinstance(result[0], Plain) and "你好" in result[0].text
    assert isinstance(result[1], At) and result[1].qq == "123"
    assert isinstance(result[2], Plain) and "世界" in result[2].text


def test_transform_mention_disabled():
    chain = [Plain(text="你好 <mention id=\"123\"/> 世界")]
    # parse_mention=False 时纯 mention 标签不做转换（has_tags 为 False → None）
    result = transform_result_chain(chain, parse_mention=False)
    assert result is None


def test_transform_quote_with_mention_disabled():
    # 含 quote 时 mention 不解析，但关闭标签会被移除
    chain = [Plain(text='回复 <quote id="msg456"/> <mention id="123"/> 内容')]
    result = transform_result_chain(chain, parse_mention=False)
    assert result is not None
    assert isinstance(result[0], Reply) and result[0].id == "456"
    assert all(not isinstance(c, At) for c in result)


def test_transform_quote():
    chain = [Plain(text='回复 <quote id="msg456"/> 内容')]
    result = transform_result_chain(chain, parse_mention=True)
    assert result is not None
    assert isinstance(result[0], Reply) and result[0].id == "456"
    rest = [c for c in result if not isinstance(c, Reply)]
    joined = "".join(c.text for c in rest if isinstance(c, Plain))
    assert "<quote" not in joined
    assert "回复" in joined


def test_no_tags_returns_none():
    chain = [Plain(text="普通文本")]
    assert transform_result_chain(chain, parse_mention=True) is None


def test_refuse_detection():
    # refuse 是严格整串匹配（参考插件语义）
    assert has_refuse_tag("<refuse/>") is True
    assert has_refuse_tag("  <refuse/>  ") is True
    assert has_refuse_tag("先输出内容 <refuse/> 不发送") is False
    assert chain_has_refuse_tag([Plain(text="<refuse/>")]) is True
    assert chain_has_refuse_tag([Plain(text="正常输出")]) is False
    # 链中混有其他内容时不视为拒绝
    assert chain_has_refuse_tag([Plain(text="<refuse/>"), Plain(text="x")]) is False


def test_clean_response_text_for_history():
    text = "你好 <mention id=\"1\"/> <quote id=\"2\"/> 再见"
    cleaned = clean_response_text_for_history(text)
    assert "<mention" not in cleaned
    assert "<quote" not in cleaned


def test_normalize_quote_id():
    assert normalize_quote_id("#msg456") == "456"
    assert normalize_quote_id("msg456") == "456"
    assert normalize_quote_id("456") == "456"
    assert normalize_quote_id("") == ""


def test_bounded_chat_history_text():
    messages = ["a", "b", "c", "d", "e"]
    text = bounded_chat_history_text(messages)
    assert "a" in text and "e" in text
