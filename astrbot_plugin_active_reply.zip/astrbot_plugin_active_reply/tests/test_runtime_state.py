from __future__ import annotations

from astrbot_plugin_active_reply.runtime_state import RuntimeState


def test_session_chats_and_touch():
    rt = RuntimeState()
    rt.touch_origin("qq:1", 500)
    assert "qq:1" in rt.origin_lru
    rt.session_chats["qq:1"].append("hello")
    assert rt.session_chats["qq:1"] == ["hello"]


def test_lru_eviction():
    rt = RuntimeState()
    for i in range(5):
        rt.touch_origin(f"qq:{i}", 3)
    # 只保留最近 3 个
    assert list(rt.origin_lru.keys()) == ["qq:2", "qq:3", "qq:4"]

    # 先填充在 LRU 中存活的最旧来源（qq:2）数据，再触发逐出
    rt.session_chats["qq:2"].append("x")
    rt.active_reply_counts["qq:2"] = 5
    rt.active_reply_stacks["qq:2"].append("m")
    rt.touch_origin("qq:5", 3)
    assert "qq:2" not in rt.session_chats
    assert "qq:2" not in rt.active_reply_counts
    assert "qq:2" not in rt.active_reply_stacks


def test_active_reply_counts_field():
    rt = RuntimeState()
    rt.active_reply_counts["qq:1"] = 7
    assert rt.active_reply_counts["qq:1"] == 7
    assert rt.active_reply_counts["qq:2"] == 0  # defaultdict


def test_cleanup_origin():
    rt = RuntimeState()
    rt.touch_origin("qq:1", 500)
    rt.session_chats["qq:1"].append("x")
    rt.active_reply_counts["qq:1"] = 3
    rt.active_reply_stacks["qq:1"].append("m")
    rt.model_choice_histories["qq:1"].append("h")
    rt.image_message_registry["qq:1"]["999"] = {"urls": []}

    rt.cleanup_origin("qq:1")
    assert "qq:1" not in rt.origin_lru
    assert "qq:1" not in rt.session_chats
    assert "qq:1" not in rt.active_reply_counts
    assert "qq:1" not in rt.active_reply_stacks
    assert "qq:1" not in rt.model_choice_histories
    assert "qq:1" not in rt.image_message_registry
