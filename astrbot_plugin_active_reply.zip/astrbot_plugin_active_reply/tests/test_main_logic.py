from __future__ import annotations

import asyncio
import types

import pytest

from astrbot.api.event import AstrMessageEvent, MessageEventResult
from astrbot.api.message_components import Plain
from astrbot.api.platform import MessageType
from astrbot.api.provider import EmbeddingProvider, LLMResponse, Provider
from astrbot.api.star import Context

from astrbot_plugin_active_reply.main import Main, PLUGIN_NAME
from plugin_config import parse_plugin_config


class FakeConversationManager:
    def __init__(self):
        self.cid = "conv-1"

    async def get_curr_conversation_id(self, origin):
        return self.cid

    async def get_conversation(self, origin, cid):
        return types.SimpleNamespace(persona_id="")


class FakePersonaManager:
    personas_v3 = []

    async def get_default_persona_v3(self, umo):
        return {"name": "default", "prompt": "You are helpful."}


class FakeContext(Context):
    def __init__(self, providers=None, base_config=None):
        self.providers = providers or []
        self.base_config = base_config or {}
        self.registered_apis = []
        self.conversation_manager = FakeConversationManager()
        self.persona_manager = FakePersonaManager()
        self.using_provider = self.providers[0] if self.providers else None

    def get_config(self, umo=None):
        return self.base_config

    def get_using_provider(self, umo=None):
        return self.using_provider

    def get_provider_by_id(self, provider_id):
        for provider in self.providers:
            if getattr(provider, "provider_id", None) == provider_id:
                return provider
        return None

    def get_all_providers(self):
        return [p for p in self.providers if isinstance(p, Provider)]

    def get_all_embedding_providers(self):
        return [p for p in self.providers if isinstance(p, EmbeddingProvider)]

    def register_web_api(self, route, handler, methods, desc):
        self.registered_apis.append(route)


class FakeChatProvider(Provider):
    def __init__(self, reply="REPLY", provider_id="judge"):
        self.provider_id = provider_id
        self._reply = reply
        self.model = "judge-model"
        self.provider_config = {"api_base": "http://x", "key": ["k"]}

    async def text_chat(self, prompt="", session_id="", image_urls=None, persist=True, **kwargs):
        return LLMResponse(completion_text=self._reply)


def make_event(origin="qq:10001", text="hello", msg_type=MessageType.GROUP_MESSAGE):
    return AstrMessageEvent(
        message_str=text,
        unified_msg_origin=origin,
        message_type=msg_type,
    )


def make_main(ctx=None, config=None):
    ctx = ctx or FakeContext()
    return Main(ctx, config or {})


def collect_results(agen):
    return asyncio.run(_collect(agen))


async def _collect(agen):
    results = []
    async for item in agen:
        results.append(item)
    return results


# ---------------- 实例化 ----------------

def test_main_instantiates():
    main = make_main()
    assert main.runtime is not None
    assert main.group_config_store is not None
    assert main.memory_rag_store is not None
    assert main._conf_schema  # 读取了 schema
    assert any(route.startswith(f"/{PLUGIN_NAME}") for route in main.context.registered_apis)
    assert len(main.context.registered_apis) >= 13


def test_main_cfg_resolution():
    ctx = FakeContext(base_config={"timezone": "UTC"})
    config = {
        "active_reply": {"enable": True, "possibility": 0.5},
        "group_reply_enhancement": {"react_pattern_enable": True},
    }
    main = make_main(ctx, config)
    cfg = main._cfg()
    assert cfg.active_reply.enable is True
    assert cfg.group_history_enabled is True

    # 群覆盖
    main.group_config_store.set(
        "qq:10001", {"active_reply": {"possibility": 0.9, "enable": False}}
    )
    cfg_group = main._cfg("qq:10001")
    assert cfg_group.active_reply.possibility == 0.9
    assert cfg_group.active_reply.enable is False
    # 未覆盖字段仍跟随全局
    assert cfg_group.group_reply.react_pattern_enable is True


# ---------------- 主动回复判定 ----------------

def test_allow_active_reply_disabled():
    main = make_main()
    cfg = main._cfg()
    event = make_event()
    assert main._allow_active_reply(event, cfg) is False  # enable=False


def test_allow_active_reply_blacklist():
    main = make_main(config={"active_reply": {"enable": True, "blacklist": ["10001"]}})
    cfg = main._cfg()
    assert main._allow_active_reply(make_event(), cfg) is False
    assert main._allow_active_reply(make_event("qq:20002"), cfg) is True


def test_allow_active_reply_whitelist():
    main = make_main(
        config={
            "active_reply": {
                "enable": True,
                "whitelist_mode": "whitelist",
                "whitelist": ["10001"],
            }
        }
    )
    cfg = main._cfg()
    assert main._allow_active_reply(make_event(), cfg) is True
    assert main._allow_active_reply(make_event("qq:20002"), cfg) is False


def test_allow_active_reply_not_group_or_at():
    main = make_main(config={"active_reply": {"enable": True}})
    cfg = main._cfg()
    event = make_event(msg_type=MessageType.PRIVATE_MESSAGE)
    assert main._allow_active_reply(event, cfg) is False

    event = make_event()
    event.is_at_or_wake_command = True
    assert main._allow_active_reply(event, cfg) is False


def test_probability_hit_and_accumulation(monkeypatch):
    main = make_main(
        config={
            "active_reply": {
                "enable": True,
                "mode": "probability",
                "possibility": 0.1,
                "trigger_accumulation": 3,
            }
        }
    )
    cfg = main._cfg()
    origin = "qq:10001"

    # 命中
    monkeypatch.setattr("astrbot_plugin_active_reply.main.random.random", lambda: 0.01)
    assert asyncio.run(main._need_active_reply(make_event(origin), cfg)) is True
    assert main.runtime.active_reply_counts[origin] == 0

    # 连续未命中：第 1、2 次 False，第 3 次强制 True
    monkeypatch.setattr("astrbot_plugin_active_reply.main.random.random", lambda: 0.99)
    assert asyncio.run(main._need_active_reply(make_event(origin), cfg)) is False
    assert main.runtime.active_reply_counts[origin] == 1
    assert asyncio.run(main._need_active_reply(make_event(origin), cfg)) is False
    assert main.runtime.active_reply_counts[origin] == 2
    assert asyncio.run(main._need_active_reply(make_event(origin), cfg)) is True
    assert main.runtime.active_reply_counts[origin] == 0  # 触发后清零


def test_model_choice_stack_accumulation(monkeypatch):
    ctx = FakeContext(providers=[FakeChatProvider(reply="REPLY")])
    main = make_main(
        ctx,
        {
            "active_reply": {
                "enable": True,
                "mode": "model_choice",
                "trigger_accumulation": 2,
            }
        },
    )
    cfg = main._cfg()
    origin = "qq:10001"

    judged = []

    async def fake_judge(event, cfg, origin_, messages, trigger_reason):
        judged.append((origin_, list(messages), trigger_reason))
        return True

    monkeypatch.setattr(main, "_judge_model_choice", fake_judge)

    first = asyncio.run(main._need_active_reply(make_event(origin, "m1"), cfg))
    assert first is False
    assert len(main.runtime.active_reply_stacks[origin]) == 1

    second = asyncio.run(main._need_active_reply(make_event(origin, "m2"), cfg))
    assert second is True
    assert len(judged) == 1
    assert len(judged[0][1]) == 2  # 两条消息参与判定
    assert judged[0][2] == "accumulation_full"
    assert len(main.runtime.active_reply_stacks[origin]) == 0  # 清空


def test_judge_model_choice_reply_and_skip():
    ctx = FakeContext(providers=[FakeChatProvider(reply="REPLY")])
    main = make_main(ctx)
    cfg = main._cfg()
    event = make_event()
    assert asyncio.run(
        main._judge_model_choice(event, cfg, "qq:10001", ["[u/1]: hi"], "test")
    ) is True

    ctx2 = FakeContext(providers=[FakeChatProvider(reply="SKIP")])
    main2 = make_main(ctx2)
    assert asyncio.run(
        main2._judge_model_choice(event, cfg, "qq:10001", ["[u/1]: hi"], "test")
    ) is False


def test_judge_model_choice_configured_provider():
    judge_provider = FakeChatProvider(reply="REPLY", provider_id="special")
    ctx = FakeContext(providers=[judge_provider])
    main = make_main(
        ctx,
        {"active_reply": {"model_choice_provider_id": "special"}},
    )
    cfg = main._cfg()
    event = make_event()
    assert asyncio.run(
        main._judge_model_choice(event, cfg, "qq:10001", ["[u/1]: hi"], "test")
    ) is True


# ---------------- /执行回复 ----------------

def test_force_reply_disabled():
    main = make_main()
    event = make_event()
    results = collect_results(main.force_reply(event))
    assert results
    joined = "".join(r.chain[0].text for r in results if r.chain and isinstance(r.chain[0], Plain))
    assert "未启用" in joined


def test_force_reply_probability_mode():
    main = make_main(config={"active_reply": {"enable": True, "mode": "probability"}})
    event = make_event()
    results = collect_results(main.force_reply(event))
    assert results
    joined = "".join(r.chain[0].text for r in results if r.chain and isinstance(r.chain[0], Plain))
    assert "已强制执行" in joined


def test_force_reply_model_choice_empty_stack():
    ctx = FakeContext(providers=[FakeChatProvider(reply="SKIP")])
    main = make_main(ctx, {"active_reply": {"enable": True, "mode": "model_choice"}})
    event = make_event()
    results = collect_results(main.force_reply(event))
    joined = "".join(r.chain[0].text for r in results if r.chain and isinstance(r.chain[0], Plain))
    # 无积累且无历史 → 提示先产生消息
    assert "没有积累" in joined or "SKIP" in joined or "不回复" in joined


# ---------------- PluginPages API ----------------

def test_api_group_flow():
    main = make_main()
    event = make_event()

    # 保存群配置
    from astrbot.api.web import request

    request._body = {"config": {"active_reply": {"enable": True, "possibility": 0.7}}}
    resp = asyncio.run(main.api_save_group_config("qq:10001"))
    assert resp.get("saved") is True
    assert main.group_config_store.has_override("qq:10001") is True
    request._body = None

    # 读取
    resp = asyncio.run(main.api_get_group_config("qq:10001"))
    assert resp["has_override"] is True
    assert resp["effective"]["active_reply"]["possibility"] == 0.7

    # 群列表
    resp = asyncio.run(main.api_list_groups())
    origins = [g["origin"] for g in resp["groups"]]
    assert "qq:10001" in origins

    # 重置
    resp = asyncio.run(main.api_reset_group_config("qq:10001"))
    assert resp["removed"] is True
    assert main.group_config_store.has_override("qq:10001") is False


def test_api_schema_and_providers():
    ctx = FakeContext(providers=[FakeChatProvider(), EmbeddingProvider()])
    main = make_main(ctx)

    resp = asyncio.run(main.api_get_schema())
    assert resp.get("active_reply") is not None
    assert resp.get("web_search") is not None

    resp = asyncio.run(main.api_list_providers())
    assert resp["providers"]
    assert resp["embedding_providers"]


def test_api_memory_flow():
    ctx = FakeContext(providers=[FakeChatProvider(), EmbeddingProvider()])
    main = make_main(ctx)

    # 写入一条记忆（直接走存储）
    embedding = [0.1, 0.2, 0.3]
    mid = main.memory_rag_store.add_memory(
        content="测试记忆内容",
        embedding=embedding,
        role_ids=["r1"],
        memory_time=1_700_000_000.0,
        group_scope="qq:10001",
    )
    assert mid > 0

    resp = asyncio.run(main.api_memory_stats())
    assert resp["data"]["total_memories"] >= 1

    resp = asyncio.run(main.api_memory_list())
    assert len(resp["data"]["items"]) >= 1

    resp = asyncio.run(main.api_memory_get(str(mid)))
    assert resp["data"]["memory_id"] == mid

    resp = asyncio.run(main.api_memory_delete_post(str(mid)))
    assert resp["success"] is True
