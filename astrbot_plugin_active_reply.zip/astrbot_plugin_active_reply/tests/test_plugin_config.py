from __future__ import annotations

from astrbot_plugin_active_reply.plugin_config import (
    BLACKLIST_MODE,
    WHITELIST_MODE,
    PluginConfig,
    merge_config_overrides,
    parse_plugin_config,
)


def test_defaults():
    cfg = parse_plugin_config({})
    assert cfg.active_reply.enable is False
    assert cfg.active_reply.mode == "probability"
    assert cfg.active_reply.possibility == 0.1
    assert cfg.active_reply.model_history_messages == 0
    assert cfg.active_reply.model_choice_provider_id == ""
    assert cfg.active_reply.trigger_accumulation == 10
    assert cfg.active_reply.whitelist_mode == BLACKLIST_MODE
    assert cfg.active_reply.blacklist == []
    assert cfg.active_reply.whitelist == []

    assert cfg.group_history.enable is True
    assert cfg.group_history.max_messages == 200
    assert cfg.group_history.include_sender_id is True
    assert cfg.group_history.include_role_tag is True
    assert cfg.group_history.image_caption is False
    assert cfg.group_history.image_caption_prompt == "Please describe the image using Chinese."

    assert cfg.group_reply.react_pattern_enable is False
    assert cfg.group_reply.role_display is True
    assert cfg.group_reply.smart_reply is True

    assert cfg.web_search.enable is False
    assert cfg.web_search.provider_id == ""
    assert cfg.web_search.timeout_sec == 60.0
    assert cfg.web_search.request_mode == "auto"
    assert cfg.web_search.show_sources is False
    assert cfg.web_search.max_sources == 5

    assert cfg.memory_rag.enable is True
    assert cfg.memory_rag.embedding_provider_id == ""
    assert cfg.memory_rag.default_recall_k == 20
    assert cfg.memory_rag.max_return_results == 100

    assert cfg.global_settings.lru_cache.max_origins == 500
    assert cfg.global_settings.timeouts.image_caption_sec == 45.0
    assert cfg.global_settings.timeouts.model_choice_sec == 45.0


def test_enablement_rules():
    # 主动回复独立于 React Pattern
    cfg = parse_plugin_config({"active_reply": {"enable": True}})
    assert cfg.active_reply_enabled is True
    assert cfg.group_history_enabled is False
    assert cfg.smart_reply_enabled is False
    assert cfg.role_display_enabled is False

    # React Pattern 开启后，上下文增强与回复增强生效（还需各自开关）
    cfg = parse_plugin_config(
        {
            "active_reply": {"enable": True},
            "group_reply_enhancement": {"react_pattern_enable": True},
        }
    )
    assert cfg.active_reply_enabled is True
    assert cfg.group_history_enabled is True
    assert cfg.smart_reply_enabled is True
    assert cfg.role_display_enabled is True

    # 子开关可以单独关闭
    cfg = parse_plugin_config(
        {
            "group_reply_enhancement": {"react_pattern_enable": True},
            "group_history_enhancement": {"enable": False},
            "group_reply_enhancement": {"react_pattern_enable": True, "smart_reply": False},
        }
    )
    assert cfg.group_history_enabled is False
    assert cfg.smart_reply_enabled is False
    assert cfg.role_display_enabled is True


def test_field_parsing_and_clamping():
    cfg = parse_plugin_config(
        {
            "active_reply": {
                "enable": "true",
                "mode": "model_choice",
                "possibility": 0.5,
                "trigger_accumulation": 99,
                "model_history_messages": 120,
            },
            "web_search": {"timeout_sec": 9999, "request_mode": "bogus"},
            "memory_rag": {"max_return_results": 9999},
            "global_settings": {
                "lru_cache": {"max_origins": 10},
                "timeouts": {"image_caption_sec": 0},
            },
        }
    )
    assert cfg.active_reply.enable is True
    assert cfg.active_reply.mode == "model_choice"
    assert cfg.active_reply.possibility == 0.5
    assert cfg.active_reply.trigger_accumulation == 50  # clamp 到上限
    assert cfg.active_reply.model_history_messages == 100  # clamp 到上限
    assert cfg.web_search.timeout_sec == 180.0  # clamp
    assert cfg.web_search.request_mode == "auto"  # 非法值回退
    assert cfg.memory_rag.max_return_results == 300
    assert cfg.global_settings.lru_cache.max_origins == 50  # 低于下限回退到下限 50
    assert cfg.global_settings.timeouts.image_caption_sec == 45.0  # 非正数回退默认


def test_whitelist_blacklist_modes():
    cfg = parse_plugin_config(
        {"active_reply": {"blacklist": ["111", "222"], "whitelist": ["333"]}}
    )
    assert cfg.is_group_allowed("100") is True
    assert cfg.is_group_allowed("111") is False
    assert cfg.is_group_allowed("222") is False
    assert cfg.is_group_allowed("") is False

    cfg = parse_plugin_config(
        {
            "active_reply": {
                "whitelist_mode": WHITELIST_MODE,
                "blacklist": ["111"],
                "whitelist": ["333"],
            }
        }
    )
    assert cfg.is_group_allowed("333") is True
    assert cfg.is_group_allowed("100") is False
    assert cfg.is_group_allowed("111") is False


def test_string_list_parsing():
    cfg = parse_plugin_config(
        {"active_reply": {"blacklist": "111, 222,333", "whitelist": ["444"]}}
    )
    assert cfg.active_reply.blacklist == ["111", "222", "333"]
    assert cfg.active_reply.whitelist == ["444"]


def test_merge_config_overrides():
    global_raw = {
        "active_reply": {
            "enable": True,
            "possibility": 0.3,
            "blacklist": ["111"],
        },
        "web_search": {"enable": True},
    }
    overrides = {
        "active_reply": {
            "possibility": 0.8,
            "blacklist": ["999"],
        }
    }
    merged = merge_config_overrides(global_raw, overrides)
    assert merged["active_reply"]["enable"] is True  # 保留
    assert merged["active_reply"]["possibility"] == 0.8  # 覆盖
    assert merged["active_reply"]["blacklist"] == ["999"]  # 整体覆盖
    assert merged["web_search"]["enable"] is True  # 未覆盖保留

    cfg = parse_plugin_config(merged)
    assert cfg.active_reply.possibility == 0.8
    assert cfg.active_reply.blacklist == ["999"]


def test_merge_does_not_mutate_inputs():
    global_raw = {"active_reply": {"enable": True}}
    overrides = {"active_reply": {"possibility": 0.5}}
    merge_config_overrides(global_raw, overrides)
    assert global_raw["active_reply"] == {"enable": True}
    assert overrides["active_reply"] == {"possibility": 0.5}
