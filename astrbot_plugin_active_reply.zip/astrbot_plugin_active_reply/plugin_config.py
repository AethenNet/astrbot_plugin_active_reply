import math
from dataclasses import dataclass, field
from typing import Any

DEFAULT_MODEL_CHOICE_PROMPT = (
    "你当前的人格面具是：{persona_name}\n"
    "人格设定如下：\n{persona_mask}\n\n"
    "你正在群聊中扮演助手。以下是最近 {stack_size} 条群聊消息：\n"
    "{messages}\n\n"
    "额外历史上下文（最近 {history_count} 条）：\n"
    "{history_context}\n\n"
    "请严格站在该人格的角度判断你是否应该主动回复。"
    "如果需要回复，只输出 REPLY；如果不需要回复，只输出 SKIP。"
)
DEFAULT_WEB_SEARCH_SYSTEM_PROMPT = (
    "You are a web research assistant. Use live web search/browsing when answering. "
    "Return ONLY a single JSON object with keys: "
    "content (string), sources (array of objects with url/title/snippet when possible). "
    "Keep content concise and evidence-backed. "
    "IMPORTANT: Do NOT use Markdown formatting in the content field - use plain text only."
)

BLACKLIST_MODE = "blacklist"
WHITELIST_MODE = "whitelist"


def _to_bool(value: Any, default: bool) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized in {"1", "true", "yes", "on"}:
            return True
        if normalized in {"0", "false", "no", "off"}:
            return False
        return default
    if isinstance(value, (int, float)):
        return bool(value)
    return default


def _to_pos_float(value: Any, default: float) -> float:
    try:
        parsed = float(value)
        return parsed if parsed > 0 else default
    except (TypeError, ValueError):
        return default


def _to_int(value: Any, default: int) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def _to_float(value: Any, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _to_probability(value: Any, default: float) -> float:
    parsed = _to_float(value, default)
    if not math.isfinite(parsed):
        parsed = default
    return min(1.0, max(0.0, parsed))


def _parse_string_list(value: Any) -> list[str]:
    if isinstance(value, str):
        return [token.strip() for token in value.split(",") if token.strip()]
    if isinstance(value, (list, tuple, set)):
        return [str(token).strip() for token in value if str(token).strip()]
    return []


def _normalize_whitelist_mode(value: Any) -> str:
    mode = str(value or BLACKLIST_MODE).strip().lower()
    return WHITELIST_MODE if mode == WHITELIST_MODE else BLACKLIST_MODE


def _normalize_reply_mode(value: Any) -> str:
    mode = str(value or "probability").strip().lower()
    return mode if mode in {"probability", "model_choice"} else "probability"


def _normalize_request_mode(value: Any) -> str:
    mode = str(value or "auto").strip().lower()
    return mode if mode in {"auto", "responses", "chat_completions"} else "auto"


def _deep_merge(base: dict[str, Any], overlay: dict[str, Any]) -> dict[str, Any]:
    """递归合并两个配置字典：overlay 中的值覆盖 base，嵌套 dict 逐层合并。

    仅合并 dict 值；其他类型（bool/int/float/str/list）整体覆盖。
    """
    result = dict(base)
    for key, value in overlay.items():
        if (
            key in result
            and isinstance(result[key], dict)
            and isinstance(value, dict)
        ):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


@dataclass(frozen=True)
class ActiveReplyConfig:
    enable: bool = False
    mode: str = "probability"
    possibility: float = 0.1
    model_history_messages: int = 0
    model_choice_provider_id: str = ""
    trigger_accumulation: int = 10
    whitelist_mode: str = BLACKLIST_MODE
    blacklist: list[str] = field(default_factory=list)
    whitelist: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class GroupHistoryEnhancementConfig:
    enable: bool = True
    max_messages: int = 200
    include_sender_id: bool = True
    include_role_tag: bool = True
    image_caption: bool = False
    image_caption_provider_id: str = ""
    image_caption_prompt: str = "Please describe the image using Chinese."


@dataclass(frozen=True)
class GroupReplyEnhancementConfig:
    react_pattern_enable: bool = False
    role_display: bool = True
    smart_reply: bool = True


@dataclass(frozen=True)
class WebSearchConfig:
    enable: bool = False
    provider_id: str = ""
    system_prompt: str = DEFAULT_WEB_SEARCH_SYSTEM_PROMPT
    timeout_sec: float = 60.0
    request_mode: str = "auto"
    base_url_override: str = ""
    show_sources: bool = False
    max_sources: int = 5


@dataclass(frozen=True)
class MemoryRAGConfig:
    enable: bool = True
    embedding_provider_id: str = ""
    default_recall_k: int = 20
    max_return_results: int = 100


@dataclass(frozen=True)
class GlobalLruConfig:
    max_origins: int = 500


@dataclass(frozen=True)
class GlobalTimeoutConfig:
    image_caption_sec: float = 45.0
    model_choice_sec: float = 45.0


@dataclass(frozen=True)
class GlobalSettingsConfig:
    lru_cache: GlobalLruConfig = field(default_factory=GlobalLruConfig)
    timeouts: GlobalTimeoutConfig = field(default_factory=GlobalTimeoutConfig)


@dataclass(frozen=True)
class PluginConfig:
    active_reply: ActiveReplyConfig = field(default_factory=ActiveReplyConfig)
    group_history: GroupHistoryEnhancementConfig = field(
        default_factory=GroupHistoryEnhancementConfig
    )
    group_reply: GroupReplyEnhancementConfig = field(
        default_factory=GroupReplyEnhancementConfig
    )
    web_search: WebSearchConfig = field(default_factory=WebSearchConfig)
    memory_rag: MemoryRAGConfig = field(default_factory=MemoryRAGConfig)
    global_settings: GlobalSettingsConfig = field(default_factory=GlobalSettingsConfig)

    @property
    def group_history_enabled(self) -> bool:
        """群聊上下文增强生效条件：React Pattern 开启 + 自身启用。"""
        return self.group_reply.react_pattern_enable and self.group_history.enable

    @property
    def active_reply_enabled(self) -> bool:
        """主动回复独立生效，不依赖 React Pattern。"""
        return self.active_reply.enable

    @property
    def smart_reply_enabled(self) -> bool:
        """智能回复（mention/quote 标签解析）生效条件：React Pattern 开启 + 自身启用。"""
        return self.group_reply.react_pattern_enable and self.group_reply.smart_reply

    @property
    def role_display_enabled(self) -> bool:
        """用户角色显示生效条件：React Pattern 开启 + 自身启用。"""
        return self.group_reply.react_pattern_enable and self.group_reply.role_display

    def is_group_allowed(self, group_id: str) -> bool:
        """根据黑/白名单模式判断群号是否允许主动回复。"""
        group_id = str(group_id or "").strip()
        if self.active_reply.whitelist_mode == WHITELIST_MODE:
            return bool(group_id) and group_id in self.active_reply.whitelist
        return bool(group_id) and group_id not in self.active_reply.blacklist


def parse_plugin_config(raw: dict[str, Any] | None) -> PluginConfig:
    raw = raw or {}

    active_reply_raw = raw.get("active_reply", {})
    active_reply = ActiveReplyConfig(
        enable=_to_bool(active_reply_raw.get("enable"), False),
        mode=_normalize_reply_mode(active_reply_raw.get("mode")),
        possibility=_to_probability(active_reply_raw.get("possibility"), 0.1),
        model_history_messages=max(
            0, min(100, _to_int(active_reply_raw.get("model_history_messages"), 0))
        ),
        model_choice_provider_id=str(
            active_reply_raw.get("model_choice_provider_id") or ""
        ).strip(),
        trigger_accumulation=max(
            2, min(50, _to_int(active_reply_raw.get("trigger_accumulation"), 10))
        ),
        whitelist_mode=_normalize_whitelist_mode(
            active_reply_raw.get("whitelist_mode")
        ),
        blacklist=_parse_string_list(active_reply_raw.get("blacklist", [])),
        whitelist=_parse_string_list(active_reply_raw.get("whitelist", [])),
    )

    group_history_raw = raw.get("group_history_enhancement", {})
    group_history = GroupHistoryEnhancementConfig(
        enable=_to_bool(group_history_raw.get("enable"), True),
        max_messages=max(
            50, min(1000, _to_int(group_history_raw.get("max_messages"), 200))
        ),
        include_sender_id=_to_bool(group_history_raw.get("include_sender_id"), True),
        include_role_tag=_to_bool(group_history_raw.get("include_role_tag"), True),
        image_caption=_to_bool(group_history_raw.get("image_caption"), False),
        image_caption_provider_id=str(
            group_history_raw.get("image_caption_provider_id") or ""
        ).strip(),
        image_caption_prompt=str(
            group_history_raw.get("image_caption_prompt")
            or "Please describe the image using Chinese."
        ),
    )

    group_reply_raw = raw.get("group_reply_enhancement", {})
    group_reply = GroupReplyEnhancementConfig(
        react_pattern_enable=_to_bool(
            group_reply_raw.get("react_pattern_enable"), False
        ),
        role_display=_to_bool(group_reply_raw.get("role_display"), True),
        smart_reply=_to_bool(group_reply_raw.get("smart_reply"), True),
    )

    web_search_raw = raw.get("web_search", {})
    configured_web_search_prompt = str(
        web_search_raw.get("system_prompt") or ""
    ).strip()
    web_search = WebSearchConfig(
        enable=_to_bool(web_search_raw.get("enable"), False),
        provider_id=str(web_search_raw.get("provider_id") or "").strip(),
        system_prompt=(
            configured_web_search_prompt
            if configured_web_search_prompt
            else DEFAULT_WEB_SEARCH_SYSTEM_PROMPT
        ),
        timeout_sec=min(
            180.0,
            max(30.0, _to_pos_float(web_search_raw.get("timeout_sec"), 60.0)),
        ),
        request_mode=_normalize_request_mode(web_search_raw.get("request_mode")),
        base_url_override=str(web_search_raw.get("base_url_override") or "").strip(),
        show_sources=_to_bool(web_search_raw.get("show_sources"), False),
        max_sources=min(20, max(0, _to_int(web_search_raw.get("max_sources"), 5))),
    )

    memory_rag_raw = raw.get("memory_rag", {})
    memory_rag = MemoryRAGConfig(
        enable=_to_bool(memory_rag_raw.get("enable"), True),
        embedding_provider_id=str(
            memory_rag_raw.get("embedding_provider_id") or ""
        ).strip(),
        default_recall_k=max(
            1, min(50, _to_int(memory_rag_raw.get("default_recall_k"), 20))
        ),
        max_return_results=max(
            1, min(300, _to_int(memory_rag_raw.get("max_return_results"), 100))
        ),
    )

    global_settings_raw = raw.get("global_settings", {})
    lru_raw = global_settings_raw.get("lru_cache", {})
    timeouts_raw = global_settings_raw.get("timeouts", {})
    global_settings = GlobalSettingsConfig(
        lru_cache=GlobalLruConfig(
            max_origins=max(
                50, min(500, _to_int(lru_raw.get("max_origins"), 500))
            )
        ),
        timeouts=GlobalTimeoutConfig(
            image_caption_sec=min(
                120.0,
                max(10.0, _to_pos_float(timeouts_raw.get("image_caption_sec"), 45.0)),
            ),
            model_choice_sec=min(
                120.0,
                max(10.0, _to_pos_float(timeouts_raw.get("model_choice_sec"), 45.0)),
            ),
        ),
    )

    return PluginConfig(
        active_reply=active_reply,
        group_history=group_history,
        group_reply=group_reply,
        web_search=web_search,
        memory_rag=memory_rag,
        global_settings=global_settings,
    )


def merge_config_overrides(
    global_raw: dict[str, Any] | None,
    overrides: dict[str, Any] | None,
) -> dict[str, Any]:
    """将某群的配置覆盖合并到全局配置之上（浅拷贝语义，不修改入参）。"""
    base = dict(global_raw or {})
    overlay = dict(overrides or {})
    if not overlay:
        return base
    return _deep_merge(base, overlay)
