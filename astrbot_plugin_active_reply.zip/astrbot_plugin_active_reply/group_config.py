from __future__ import annotations

import json
import threading
from pathlib import Path
from typing import Any


class GroupConfigStore:
    """每个群的独立配置覆盖存储。

    只保存用户在 PluginPages 中针对某个 unified_msg_origin 修改过的覆盖项，
    不保存全量配置，因此全局配置变化时未覆盖的字段会自动跟随全局。
    持久化位置：data/plugin_data/astrbot_plugin_active_reply/group_configs.json
    """

    def __init__(self, data_dir: Path) -> None:
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self._store_path = self.data_dir / "group_configs.json"
        self._lock = threading.RLock()
        self._configs: dict[str, dict[str, Any]] = {}
        self._load()

    def _load(self) -> None:
        if not self._store_path.exists():
            return
        try:
            raw = json.loads(self._store_path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                for origin, cfg in raw.items():
                    if isinstance(origin, str) and origin.strip() and isinstance(cfg, dict):
                        self._configs[origin] = cfg
        except (json.JSONDecodeError, OSError):
            # 配置文件损坏时保留空状态，避免插件启动失败
            self._configs = {}

    def _save(self) -> None:
        with self._lock:
            self._store_path.write_text(
                json.dumps(self._configs, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

    def get(self, origin: str) -> dict[str, Any] | None:
        origin = str(origin or "").strip()
        if not origin:
            return None
        with self._lock:
            stored = self._configs.get(origin)
            if not isinstance(stored, dict):
                return None
            # 深拷贝，防止调用方修改内部状态
            return json.loads(json.dumps(stored, ensure_ascii=False))

    def set(self, origin: str, config: dict[str, Any] | None) -> None:
        origin = str(origin or "").strip()
        if not origin:
            return
        with self._lock:
            if not isinstance(config, dict) or not config:
                self._configs.pop(origin, None)
            else:
                self._configs[origin] = json.loads(
                    json.dumps(config, ensure_ascii=False)
                )
            self._save()

    def delete(self, origin: str) -> bool:
        origin = str(origin or "").strip()
        if not origin:
            return False
        with self._lock:
            existed = origin in self._configs
            if existed:
                self._configs.pop(origin, None)
                self._save()
            return existed

    def list_origins(self) -> list[str]:
        with self._lock:
            return list(self._configs.keys())

    def has_override(self, origin: str) -> bool:
        origin = str(origin or "").strip()
        if not origin:
            return False
        with self._lock:
            return origin in self._configs
